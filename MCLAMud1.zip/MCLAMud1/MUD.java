/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mud;
import java.io.IOException;
import java.util.Scanner;

public class MUD {
    public static void main(String[] args) throws IOException{
        Scanner playerInput = new Scanner(System.in);
        Player p = new Player();
        World.movePlayer(p, 3);
        World.displayArea(p.location);
        System.out.print(">> ");
        String command = playerInput.nextLine();
        processCommand(command);
    }
    
    private static void processCommand(String cmd){
        String[] words = cmd.trim().toLowerCase().split(" ");
        //System.out.println(words[0] + words[1]);
        switch(words[0]){
            case "walk":
            case "go":
                break;
            default:
                System.out.println("What do you mean by " + words[0] + "?" );
        }
    }
}
    
   